Slate Discord Bot

Slate is a Discord moderation and security bot built to protect servers from raids, spam, and destructive actions. It monitors server activity in real time and responds instantly when dangerous behavior is detected.

Core Features

- Real time raid and nuke protection
- Detection of mass channel deletes, role permission abuse, ban spikes, and join floods
- Automatic lockdown system to stop damage
- Advanced automod for spam, link flooding, mass mentions, and blacklisted words
- Member verification with role gating
- Join screening for low age or suspicious accounts
- Detailed moderation and security logs
- Per server configuration stored in MongoDB

Requirements

- Node.js 18 or newer
- MongoDB Atlas database
- Discord bot with privileged intents enabled

Environment Variables

DISCORD_TOKEN=your bot token
CLIENT_ID=your application id
MONGODB_URI=your mongodb connection string

Commands

/setup
/lockdown
/backup
/restore
/config
/whitelist

License

MIT License
